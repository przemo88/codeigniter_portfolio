<?php

echo 'to jest plik test.php';

?>